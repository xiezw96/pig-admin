export enum CouponStatus {
  未生效,
  正常,
  已失效,
}
