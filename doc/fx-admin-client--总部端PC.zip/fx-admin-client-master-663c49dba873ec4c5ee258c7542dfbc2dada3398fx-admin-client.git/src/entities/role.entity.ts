export class RoleEntity {
  name: string;

  operator: number;

  updateTime: string;
}
