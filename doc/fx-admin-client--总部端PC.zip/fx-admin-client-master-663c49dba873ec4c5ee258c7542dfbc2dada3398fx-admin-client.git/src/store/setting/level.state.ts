export interface LevelState {
  loading: boolean;
  list: any[];
  levels: any[];
}
