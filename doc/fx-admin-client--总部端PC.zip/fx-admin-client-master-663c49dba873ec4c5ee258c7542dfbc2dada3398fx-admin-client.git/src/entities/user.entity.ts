export class UserEntity {
  name: string;
}
