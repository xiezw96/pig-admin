export interface FindRolesDto {
  name: string;
}
