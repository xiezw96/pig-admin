import { GoodsCaterogy } from '@/interfaces';

export interface CategoryState {
  list: GoodsCaterogy[];
}
