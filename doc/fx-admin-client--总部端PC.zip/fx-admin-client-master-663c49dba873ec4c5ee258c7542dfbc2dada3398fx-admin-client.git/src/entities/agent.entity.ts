export class AgentEntity {}
