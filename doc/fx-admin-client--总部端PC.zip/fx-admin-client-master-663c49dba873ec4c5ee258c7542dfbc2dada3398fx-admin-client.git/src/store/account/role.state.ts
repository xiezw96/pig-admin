import { RoleEntity } from '@/entities';

export interface RoleState {
  roles: RoleEntity[];
}
