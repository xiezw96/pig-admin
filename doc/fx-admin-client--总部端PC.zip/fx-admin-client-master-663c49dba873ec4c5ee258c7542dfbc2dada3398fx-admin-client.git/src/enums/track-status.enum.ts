export enum TrackStatus {
  正常 = 1,
  故障,
  补货,
}
