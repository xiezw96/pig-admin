export interface CreateLevelDto {
  name: string;

  weight: number;
}
