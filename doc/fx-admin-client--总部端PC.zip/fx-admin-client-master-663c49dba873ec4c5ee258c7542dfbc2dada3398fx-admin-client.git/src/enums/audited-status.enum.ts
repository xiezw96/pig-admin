export enum AuditedStatus {
  待处理,
  通过,
  拒绝,
}
