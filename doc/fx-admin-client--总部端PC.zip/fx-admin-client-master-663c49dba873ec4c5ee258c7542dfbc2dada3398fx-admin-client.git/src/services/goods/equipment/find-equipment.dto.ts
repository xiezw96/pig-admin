export interface FindEquipmentDto {
  code?: string;
  name?: string;
  status?: number;
  currAddreaa?: string;

  current: number;
  size: number;
}
