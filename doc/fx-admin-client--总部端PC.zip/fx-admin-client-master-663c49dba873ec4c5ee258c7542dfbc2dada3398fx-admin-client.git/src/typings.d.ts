declare module 'ant-design-vue/lib/locale-provider/zh_CN';
