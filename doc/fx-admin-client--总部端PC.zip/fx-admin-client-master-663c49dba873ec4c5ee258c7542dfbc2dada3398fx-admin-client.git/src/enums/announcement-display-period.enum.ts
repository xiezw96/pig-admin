export const enum AnnouncementDisplayPerriod {
  仅一次,
  每周一次,
  每月一次,
}
