export enum LogisticsStatus {
  未发货 = 1,
  已发货,
}
