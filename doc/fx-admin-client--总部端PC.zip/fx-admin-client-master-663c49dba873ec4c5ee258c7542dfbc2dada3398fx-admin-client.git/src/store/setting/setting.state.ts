import { LevelState } from './level.state';

export interface SettingState {
  level: LevelState;
}
