export const PAGINATION = {
  current: 1,
  size: 1000000,
};
