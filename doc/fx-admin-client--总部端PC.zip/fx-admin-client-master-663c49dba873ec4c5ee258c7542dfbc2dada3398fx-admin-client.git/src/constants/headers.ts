export const TOKEN_NEEDED = 'X-Token-Needed';
