import { a2b } from '@/utils';

export function a2bFilter(base64: string) {
  return a2b(base64);
}
