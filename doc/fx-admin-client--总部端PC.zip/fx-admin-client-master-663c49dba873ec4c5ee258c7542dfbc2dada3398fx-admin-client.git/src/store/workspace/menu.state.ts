export class MenuState {
  openKeys: string[] = [];
  selectedKeys: string[] = [];
}
