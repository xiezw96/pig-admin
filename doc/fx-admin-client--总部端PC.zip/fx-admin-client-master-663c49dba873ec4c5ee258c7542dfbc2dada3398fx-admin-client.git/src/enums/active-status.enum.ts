export enum ActiveStatus {
  待激活,
  正常,
  冻结,
}
