import { UserEntity } from '@/entities';

export interface UserState {
  users?: UserEntity[];
}
