import { FieldDecoratorOptions } from 'ant-design-vue/types/form/form';

export type FormControl = [string] | [string, FieldDecoratorOptions];
