export enum PaymentApproach {
  微信,
  支付宝,
  银联,
}
