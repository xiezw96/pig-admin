export enum ActivateType {
  自购柜子,
  购买指定商品组合,
  购买指定金额商品,
}
