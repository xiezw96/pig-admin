import { AgentEntity } from '@/entities';

export interface AgentState {
  agents: AgentEntity;
}
