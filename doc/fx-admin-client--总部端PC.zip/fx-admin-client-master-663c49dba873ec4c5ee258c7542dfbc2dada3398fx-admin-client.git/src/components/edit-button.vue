<template>
  <a-tooltip>
    <template #title>编辑</template>
    <a-button size="small" shape="circle" icon="edit" v-bind="$attrs" v-on="$listeners"></a-button>
  </a-tooltip>
</template>
