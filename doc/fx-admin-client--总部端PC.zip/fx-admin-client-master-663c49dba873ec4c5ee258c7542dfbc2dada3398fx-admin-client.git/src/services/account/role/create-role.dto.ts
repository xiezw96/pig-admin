export interface CreateRoleDto {
  roleName: string;
}
