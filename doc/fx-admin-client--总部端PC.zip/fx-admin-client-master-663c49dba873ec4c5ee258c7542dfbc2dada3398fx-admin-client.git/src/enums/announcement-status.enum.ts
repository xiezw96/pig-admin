export enum AnnouncementStatus {
  开启,
  关闭,
}
