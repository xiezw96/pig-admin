export const enum EditingMode {
  无,
  新增,
  编辑,
}
