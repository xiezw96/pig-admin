export interface FindAgentsDto {
  name: string;

  phone: string;

  recommander: string;
}
