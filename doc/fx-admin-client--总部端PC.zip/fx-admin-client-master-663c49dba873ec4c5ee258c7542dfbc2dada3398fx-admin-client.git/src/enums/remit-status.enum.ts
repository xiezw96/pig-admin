export enum RemitdStatus {
  待打款,
  已打款
}
