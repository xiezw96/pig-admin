export enum DeviceStatus {
  待激活,
  正常,
  故障,
  补货,
  开门,
  离线,
  回收,
}
