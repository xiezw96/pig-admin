export const WX_AUTHORIZATION_URL =
  'https://open.weixin.qq.com/connect/oauth2/authorize';
